options(test.verbose=FALSE)
BiocGenerics:::testPackage("gdsfmt")
