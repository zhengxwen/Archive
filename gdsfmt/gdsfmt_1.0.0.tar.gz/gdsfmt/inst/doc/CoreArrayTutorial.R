### R code from vignette source 'CoreArrayTutorial.Rnw'

