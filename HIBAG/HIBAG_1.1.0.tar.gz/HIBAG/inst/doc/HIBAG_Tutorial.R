### R code from vignette source 'HIBAG_Tutorial.Rnw'

